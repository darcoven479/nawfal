import { GoogleGenAI } from "@google/genai";
import { ToolConfig } from "../types";

// Helper to convert base64 to blob/data for generic usage if needed, 
// though Gemini accepts base64 string in inlineData.

const getModel = (highQuality: boolean) => {
  return highQuality ? 'gemini-3-pro-image-preview' : 'gemini-2.5-flash-image';
};

export const generateImageWithGemini = async (
  prompt: string,
  config: ToolConfig
): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is missing.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const modelName = getModel(config.highQuality);

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        imageConfig: {
          aspectRatio: config.aspectRatio,
          // imageSize only supported on pro-image-preview
          ...(config.highQuality ? { imageSize: config.imageSize } : {})
        }
      }
    });

    // Extract image
    if (response.candidates && response.candidates[0].content.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          const mimeType = part.inlineData.mimeType || 'image/png';
          return `data:${mimeType};base64,${part.inlineData.data}`;
        }
      }
    }
    
    throw new Error("No image generated.");
  } catch (error: any) {
    console.error("Generation Error:", error);
    throw new Error(error.message || "Failed to generate image.");
  }
};

export const editImageWithGemini = async (
  imageBase64: string,
  prompt: string,
  config: ToolConfig
): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is missing.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const modelName = getModel(config.highQuality);

  // Detect mime type
  const mimeType = imageBase64.match(/^data:(image\/\w+);base64,/)?.[1] || 'image/png';
  // Strip prefix
  const base64Data = imageBase64.replace(/^data:image\/\w+;base64,/, "");

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Data,
              mimeType: mimeType,
            },
          },
          {
            text: prompt,
          },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: config.aspectRatio,
           ...(config.highQuality ? { imageSize: config.imageSize } : {})
        }
      }
    });

    if (response.candidates && response.candidates[0].content.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          const mimeType = part.inlineData.mimeType || 'image/png';
          return `data:${mimeType};base64,${part.inlineData.data}`;
        }
      }
    }
    throw new Error("No edited image returned.");
  } catch (error: any) {
    console.error("Editing Error:", error);
    throw new Error(error.message || "Failed to edit image.");
  }
};

export const describeImageWithGemini = async (
  imageBase64: string
): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is missing.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  // Using Flash for fast multimodal understanding
  const modelName = 'gemini-2.5-flash';

  // Detect mime type
  const mimeType = imageBase64.match(/^data:(image\/\w+);base64,/)?.[1] || 'image/png';
  // Strip prefix
  const base64Data = imageBase64.replace(/^data:image\/\w+;base64,/, "");

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Data,
              mimeType: mimeType,
            },
          },
          {
            text: "Analyze this image and provide a highly detailed text prompt that could be used to generate an image very similar to this one. Focus on style, lighting, composition, and subject matter.",
          },
        ],
      },
    });

    if (response.candidates && response.candidates[0].content.parts) {
      // Find text part
      const textPart = response.candidates[0].content.parts.find(p => p.text);
      if (textPart && textPart.text) {
        return textPart.text;
      }
    }
    throw new Error("No description returned.");
  } catch (error: any) {
    console.error("Description Error:", error);
    throw new Error(error.message || "Failed to describe image.");
  }
};