export enum AppView {
  LANDING = 'LANDING',
  APP = 'APP'
}

export enum ToolMode {
  GENERATE = 'GENERATE',
  EDIT = 'EDIT',
  REMOVE_BG = 'REMOVE_BG',
  ENHANCE = 'ENHANCE',
  IMAGE_TO_PROMPT = 'IMAGE_TO_PROMPT'
}

export interface GeneratedImage {
  url: string;
  prompt: string;
  timestamp: number;
}

export interface ToolConfig {
  aspectRatio: string;
  imageSize: string;
  highQuality: boolean;
}
