import React from 'react';
import { ArrowLeft, Sparkles, Image as ImageIcon, Zap, Layers } from 'lucide-react';
import { AppView } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  currentView: AppView;
  onNavigate: (view: AppView) => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, currentView, onNavigate }) => {
  return (
    <div className="min-h-screen flex flex-col relative z-10">
      <header className="sticky top-0 z-50 bg-slate-900/80 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div 
                className="flex items-center gap-2 cursor-pointer" 
                onClick={() => onNavigate(AppView.LANDING)}
            >
              <div className="bg-gradient-to-tr from-indigo-500 to-purple-500 p-2 rounded-lg">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-xl tracking-tight text-white">PixelMagic<span className="text-indigo-400">AI</span></span>
            </div>
            
            <nav className="hidden md:flex gap-8 text-sm font-medium text-slate-300">
                <button onClick={() => onNavigate(AppView.LANDING)} className="hover:text-white transition">Home</button>
                <button className="hover:text-white transition">Features</button>
                <button className="hover:text-white transition">Pricing</button>
            </nav>

            <div className="flex items-center gap-4">
              {currentView === AppView.LANDING ? (
                <button 
                  onClick={() => onNavigate(AppView.APP)}
                  className="bg-white text-slate-900 px-4 py-2 rounded-full font-semibold hover:bg-indigo-50 transition shadow-lg shadow-indigo-500/20 text-sm"
                >
                  Launch App
                </button>
              ) : (
                <button 
                    onClick={() => onNavigate(AppView.LANDING)}
                    className="text-slate-400 hover:text-white flex items-center gap-2 text-sm"
                >
                    <ArrowLeft className="w-4 h-4" /> Exit
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="flex-grow">
        {children}
      </main>

      <footer className="bg-slate-900 border-t border-slate-800 py-12">
        <div className="max-w-7xl mx-auto px-4 text-center text-slate-500">
          <div className="flex justify-center gap-6 mb-8">
            <Layers className="w-6 h-6" />
            <ImageIcon className="w-6 h-6" />
            <Zap className="w-6 h-6" />
          </div>
          <p>© 2024 PixelMagic AI. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};
