import React, { useState, useRef, useEffect } from 'react';
import { ToolMode, ToolConfig } from '../types';
import { generateImageWithGemini, editImageWithGemini, describeImageWithGemini } from '../services/geminiService';
import { Wand2, Image as ImageIcon, Eraser, Download, Upload, Loader2, Sparkles, ZoomIn, FileText, Copy, Check } from 'lucide-react';

export const AppWorkspace: React.FC = () => {
  const [activeTool, setActiveTool] = useState<ToolMode>(ToolMode.GENERATE);
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [generatedText, setGeneratedText] = useState<string | null>(null);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [config, setConfig] = useState<ToolConfig>({
    aspectRatio: "1:1",
    imageSize: "1K",
    highQuality: false
  });

  // Load state from localStorage on mount
  useEffect(() => {
    const savedState = localStorage.getItem('pixelmagic_workspace_state');
    if (savedState) {
      try {
        const parsed = JSON.parse(savedState);
        if (parsed.activeTool) setActiveTool(parsed.activeTool);
        if (parsed.prompt) setPrompt(parsed.prompt);
        if (parsed.uploadedImage) setUploadedImage(parsed.uploadedImage);
        if (parsed.generatedImage) setGeneratedImage(parsed.generatedImage);
        if (parsed.generatedText) setGeneratedText(parsed.generatedText);
        if (parsed.config) setConfig(parsed.config);
      } catch (e) {
        console.error("Failed to restore workspace state:", e);
      }
    }
  }, []);

  // Save state to localStorage with debounce
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      const stateToSave = {
        activeTool,
        prompt,
        uploadedImage,
        generatedImage,
        generatedText,
        config
      };
      try {
        localStorage.setItem('pixelmagic_workspace_state', JSON.stringify(stateToSave));
      } catch (e) {
        // Silently fail if quota exceeded (common with large base64 images)
        console.warn("Could not save state to localStorage (likely quota exceeded).");
      }
    }, 1000); // 1 second debounce

    return () => clearTimeout(timeoutId);
  }, [activeTool, prompt, uploadedImage, generatedImage, generatedText, config]);

  const getClosestAspectRatio = (width: number, height: number): string => {
    const ratio = width / height;
    const supportedRatios = {
      "1:1": 1,
      "3:4": 0.75,
      "4:3": 1.333,
      "9:16": 0.5625,
      "16:9": 1.777
    };
    
    let closest = "1:1";
    let minDiff = Number.MAX_VALUE;

    for (const [key, val] of Object.entries(supportedRatios)) {
      const diff = Math.abs(ratio - val);
      if (diff < minDiff) {
        minDiff = diff;
        closest = key;
      }
    }
    return closest;
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setUploadedImage(result);
        setGeneratedImage(null);
        setGeneratedText(null);
        
        const img = new Image();
        img.onload = () => {
          const newRatio = getClosestAspectRatio(img.width, img.height);
          setConfig(prev => ({ ...prev, aspectRatio: newRatio }));
        };
        img.src = result;
      };
      reader.readAsDataURL(file);
    }
  };

  /**
   * Prepares an image for masking by placing it in a square container (1:1).
   * This prevents aspect ratio distortion when Gemini processes it, as Gemini defaults to 1:1.
   * Returns the padded image as base64 and layout info to reverse the process.
   */
  const prepareForMasking = async (src: string): Promise<{
    paddedBase64: string;
    originalWidth: number;
    originalHeight: number;
    paddedSize: number;
    xOffset: number;
    yOffset: number;
  }> => {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => {
            const size = Math.max(img.width, img.height);
            const canvas = document.createElement('canvas');
            canvas.width = size;
            canvas.height = size;
            const ctx = canvas.getContext('2d');
            if (!ctx) {
                reject(new Error("Canvas error"));
                return;
            }

            // Fill with black (background for the mask generation)
            ctx.fillStyle = "#000000";
            ctx.fillRect(0, 0, size, size);

            // Center image
            const x = (size - img.width) / 2;
            const y = (size - img.height) / 2;
            ctx.drawImage(img, x, y);

            resolve({
                paddedBase64: canvas.toDataURL('image/png'),
                originalWidth: img.width,
                originalHeight: img.height,
                paddedSize: size,
                xOffset: x,
                yOffset: y
            });
        };
        img.onerror = reject;
        img.src = src;
    });
  };

  const applyMaskToImage = async (
      originalSrc: string, 
      maskSrc: string, 
      layout?: { xOffset: number; yOffset: number; paddedSize: number }
  ): Promise<string> => {
    return new Promise((resolve, reject) => {
        const original = new Image();
        const mask = new Image();
        
        let loaded = 0;
        const onLoaded = () => {
            loaded++;
            if (loaded === 2) {
                process();
            }
        };

        original.onload = onLoaded;
        mask.onload = onLoaded;
        original.onerror = reject;
        mask.onerror = reject;

        original.src = originalSrc;
        mask.src = maskSrc;

        const process = () => {
            const canvas = document.createElement('canvas');
            canvas.width = original.width;
            canvas.height = original.height;
            const ctx = canvas.getContext('2d');
            if (!ctx) {
                reject(new Error("Could not get canvas context"));
                return;
            }

            // 1. Draw original image
            ctx.drawImage(original, 0, 0);
            const originalData = ctx.getImageData(0, 0, canvas.width, canvas.height);

            // 2. Process Mask
            // The mask usually comes back as 1:1 (e.g. 1024x1024).
            // We need to map it back to the original coordinates.
            
            const maskCanvas = document.createElement('canvas');
            if (layout) {
                // If we used padding, the mask corresponds to the square container.
                maskCanvas.width = layout.paddedSize;
                maskCanvas.height = layout.paddedSize;
            } else {
                // Fallback for simple stretch
                maskCanvas.width = canvas.width;
                maskCanvas.height = canvas.height;
            }
            
            const maskCtx = maskCanvas.getContext('2d');
            if (!maskCtx) {
                 reject(new Error("Could not get mask canvas context"));
                 return;
            }
            
            // Draw the generated mask onto the sizing canvas
            maskCtx.drawImage(mask, 0, 0, maskCanvas.width, maskCanvas.height);
            
            // Now extract the relevant part of the mask
            let finalMaskData: ImageData;
            
            if (layout) {
                // Crop the relevant area from the padded mask
                finalMaskData = maskCtx.getImageData(layout.xOffset, layout.yOffset, canvas.width, canvas.height);
            } else {
                finalMaskData = maskCtx.getImageData(0, 0, canvas.width, canvas.height);
            }

            // 3. Apply Alpha with Levels Correction
            // This preserves semi-transparent edges (like hair) while removing background noise.
            const blackPoint = 20; // Cutoff for dark noise in the mask
            const whitePoint = 235; // Cutoff for solid opacity

            for (let i = 0; i < originalData.data.length; i += 4) {
                // Mask: White (255) = Keep, Black (0) = Transparent
                // We use Red channel from the grayscale mask.
                let alpha = finalMaskData.data[i];
                
                // Levels Adjustment Logic
                if (alpha < blackPoint) {
                    alpha = 0;
                } else if (alpha > whitePoint) {
                    alpha = 255;
                } else {
                    // Map range [blackPoint, whitePoint] to [0, 255]
                    alpha = Math.round(((alpha - blackPoint) / (whitePoint - blackPoint)) * 255);
                }

                originalData.data[i + 3] = alpha;
            }

            ctx.putImageData(originalData, 0, 0);
            resolve(canvas.toDataURL('image/png'));
        };
    });
  };

  const handleAction = async () => {
    setIsLoading(true);
    setError(null);
    try {
      let result = '';

      if (activeTool === ToolMode.GENERATE) {
        if (!prompt) throw new Error("Please enter a prompt.");
        result = await generateImageWithGemini(prompt, config);
        setGeneratedImage(result);
        setGeneratedText(null);
      } else if (activeTool === ToolMode.IMAGE_TO_PROMPT) {
         if (!uploadedImage) throw new Error("Please upload an image first.");
         const text = await describeImageWithGemini(uploadedImage);
         setGeneratedText(text);
         setGeneratedImage(null);
      } else {
        if (!uploadedImage) throw new Error("Please upload an image first.");
        
        if (activeTool === ToolMode.REMOVE_BG) {
            // 1. Prepare image (Pad to 1:1 to ensure Gemini doesn't warp it)
            const layout = await prepareForMasking(uploadedImage);
            
            // 2. Generate Mask using Padded Image
            // We request a "grayscale alpha matte" to support soft edges (hair, fur)
            const maskPrompt = "Generate a precise grayscale alpha matte for the main subject. White represents the subject, black represents the background. Use gray values for semi-transparent details like hair, fur, or glass. Ensure the subject is completely isolated from the background.";
            
            // Force 1:1 config for the mask generation step
            const maskConfig: ToolConfig = {
                ...config,
                aspectRatio: "1:1" // Crucial: matches our padded image
            };

            const maskResult = await editImageWithGemini(layout.paddedBase64, maskPrompt, maskConfig);
            
            // 3. Apply Mask (Crop/Unpad and Apply with levels correction)
            result = await applyMaskToImage(uploadedImage, maskResult, {
                xOffset: layout.xOffset,
                yOffset: layout.yOffset,
                paddedSize: layout.paddedSize
            });
            
        } else {
            // Standard Edit / Enhance
            let finalPrompt = prompt;
            if (activeTool === ToolMode.ENHANCE) {
                finalPrompt = "Upscale and improve the clarity, sharpness, and lighting of this image. Maintain the original subject details. " + (prompt || "");
            }
            if (!finalPrompt && activeTool === ToolMode.EDIT) throw new Error("Please describe the edit.");
            result = await editImageWithGemini(uploadedImage, finalPrompt, config);
        }

        setGeneratedImage(result);
        setGeneratedText(null);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = () => {
    if (generatedText) {
      navigator.clipboard.writeText(generatedText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="h-[calc(100vh-64px)] flex flex-col md:flex-row bg-slate-900">
      {/* Sidebar Tools */}
      <div className="w-full md:w-80 bg-slate-800 border-r border-slate-700 p-6 flex flex-col gap-6 overflow-y-auto">
        
        <div>
          <h3 className="text-slate-400 text-xs font-bold uppercase tracking-wider mb-4">Select Tool</h3>
          <div className="grid grid-cols-2 gap-2">
            <button 
              onClick={() => setActiveTool(ToolMode.GENERATE)}
              className={`p-3 rounded-xl flex flex-col items-center gap-2 transition border ${activeTool === ToolMode.GENERATE ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-slate-700 border-slate-600 text-slate-300 hover:bg-slate-600'}`}
            >
              <ImageIcon className="w-5 h-5" />
              <span className="text-xs font-medium">Generate</span>
            </button>
            <button 
              onClick={() => setActiveTool(ToolMode.EDIT)}
              className={`p-3 rounded-xl flex flex-col items-center gap-2 transition border ${activeTool === ToolMode.EDIT ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-slate-700 border-slate-600 text-slate-300 hover:bg-slate-600'}`}
            >
              <Wand2 className="w-5 h-5" />
              <span className="text-xs font-medium">Edit</span>
            </button>
            <button 
              onClick={() => setActiveTool(ToolMode.REMOVE_BG)}
              className={`p-3 rounded-xl flex flex-col items-center gap-2 transition border ${activeTool === ToolMode.REMOVE_BG ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-slate-700 border-slate-600 text-slate-300 hover:bg-slate-600'}`}
            >
              <Eraser className="w-5 h-5" />
              <span className="text-xs font-medium">Remove BG</span>
            </button>
            <button 
              onClick={() => setActiveTool(ToolMode.ENHANCE)}
              className={`p-3 rounded-xl flex flex-col items-center gap-2 transition border ${activeTool === ToolMode.ENHANCE ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-slate-700 border-slate-600 text-slate-300 hover:bg-slate-600'}`}
            >
              <ZoomIn className="w-5 h-5" />
              <span className="text-xs font-medium">Enhance</span>
            </button>
            <button 
              onClick={() => setActiveTool(ToolMode.IMAGE_TO_PROMPT)}
              className={`p-3 rounded-xl flex flex-col items-center gap-2 transition border col-span-2 ${activeTool === ToolMode.IMAGE_TO_PROMPT ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-slate-700 border-slate-600 text-slate-300 hover:bg-slate-600'}`}
            >
              <FileText className="w-5 h-5" />
              <span className="text-xs font-medium">Image to Prompt</span>
            </button>
          </div>
        </div>

        <div className="h-px bg-slate-700" />

        {/* Input Area */}
        <div className="space-y-4">
          
          {activeTool !== ToolMode.GENERATE && (
             <div className="space-y-2">
                <label className="text-slate-300 text-sm font-medium">Source Image</label>
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-slate-600 rounded-xl p-4 cursor-pointer hover:border-indigo-500 hover:bg-slate-700/50 transition flex flex-col items-center justify-center text-center h-32"
                >
                    {uploadedImage ? (
                        <img src={uploadedImage} alt="Upload" className="h-full object-contain" />
                    ) : (
                        <>
                            <Upload className="w-6 h-6 text-slate-400 mb-2" />
                            <span className="text-xs text-slate-400">Click to upload</span>
                        </>
                    )}
                    <input 
                        type="file" 
                        ref={fileInputRef} 
                        onChange={handleFileUpload} 
                        accept="image/*"
                        className="hidden" 
                    />
                </div>
             </div>
          )}

          {activeTool !== ToolMode.IMAGE_TO_PROMPT && (
            <div className="space-y-2">
              <label className="text-slate-300 text-sm font-medium">
                  {activeTool === ToolMode.REMOVE_BG ? 'Additional Details (Optional)' : 'Prompt'}
              </label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder={activeTool === ToolMode.GENERATE ? "A futuristic city on mars..." : "Describe the changes..."}
                className="w-full bg-slate-900 border border-slate-600 rounded-lg p-3 text-sm text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent min-h-[100px] resize-none"
              />
            </div>
          )}

          {activeTool !== ToolMode.IMAGE_TO_PROMPT && (
            <div className="space-y-4">
              <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                      type="checkbox" 
                      checked={config.highQuality}
                      onChange={(e) => setConfig(prev => ({...prev, highQuality: e.target.checked}))}
                      className="w-4 h-4 rounded border-slate-600 text-indigo-600 focus:ring-indigo-500 bg-slate-700"
                  />
                  <span className="text-sm text-slate-300">High Quality Mode (Pro)</span>
              </label>
              
              {/* Aspect Ratio - Simple Selector */}
              <div className="space-y-2">
                  <label className="text-slate-300 text-xs uppercase font-bold">Aspect Ratio</label>
                  <div className="flex gap-2">
                      {['1:1', '16:9', '9:16', '3:4', '4:3'].map(ratio => (
                          <button
                              key={ratio}
                              onClick={() => setConfig(prev => ({...prev, aspectRatio: ratio}))}
                              className={`px-3 py-1 text-xs rounded-md border ${config.aspectRatio === ratio ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300' : 'bg-slate-700 border-slate-600 text-slate-400'}`}
                          >
                              {ratio}
                          </button>
                      ))}
                  </div>
              </div>
            </div>
          )}

          <button
            onClick={handleAction}
            disabled={isLoading}
            className={`w-full py-3 rounded-lg font-bold flex items-center justify-center gap-2 transition ${isLoading ? 'bg-indigo-600/50 cursor-not-allowed' : 'bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 text-white shadow-lg shadow-indigo-500/20'}`}
          >
            {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
            {activeTool === ToolMode.GENERATE ? 'Generate' : activeTool === ToolMode.IMAGE_TO_PROMPT ? 'Analyze Image' : 'Process'}
          </button>
          
          {error && (
            <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-xs">
                {error}
            </div>
          )}

        </div>
      </div>

      {/* Main Canvas Area */}
      <div className="flex-grow p-6 flex flex-col items-center justify-center bg-slate-900 relative overflow-hidden">
        {/* Grid Background Pattern */}
        <div className="absolute inset-0 z-0 opacity-20 pointer-events-none" style={{
            backgroundImage: 'radial-gradient(#475569 1px, transparent 1px)',
            backgroundSize: '20px 20px'
        }}></div>

        <div className="relative z-10 w-full max-w-4xl h-full flex flex-col">
            <div className="flex-grow bg-slate-800/50 backdrop-blur border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex items-center justify-center relative group">
                
                {/* Generated Image Result */}
                {generatedImage ? (
                    <img src={generatedImage} alt="Result" className="max-w-full max-h-full object-contain" />
                ) : generatedText ? (
                    /* Text Result for Image to Prompt */
                    <div className="relative w-full h-full flex items-center justify-center p-8">
                       {uploadedImage && <img src={uploadedImage} alt="Background" className="absolute inset-0 w-full h-full object-cover opacity-10 blur-xl" />}
                       <div className="bg-slate-900/80 backdrop-blur-md border border-slate-600 p-8 rounded-xl max-w-2xl w-full relative">
                          <h3 className="text-white font-bold mb-4 flex items-center gap-2">
                             <Sparkles className="w-5 h-5 text-indigo-400" /> AI Generated Prompt
                          </h3>
                          <div className="bg-slate-800 p-4 rounded-lg border border-slate-700 text-slate-300 text-sm leading-relaxed max-h-[400px] overflow-y-auto">
                              {generatedText}
                          </div>
                          <button 
                             onClick={copyToClipboard}
                             className="mt-4 flex items-center gap-2 text-indigo-400 hover:text-white font-medium text-sm transition"
                          >
                             {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                             {copied ? 'Copied to clipboard' : 'Copy prompt'}
                          </button>
                       </div>
                    </div>
                ) : uploadedImage && activeTool !== ToolMode.GENERATE ? (
                    <div className="relative">
                        <img src={uploadedImage} alt="Preview" className="max-w-full max-h-[70vh] object-contain opacity-50" />
                        <div className="absolute inset-0 flex items-center justify-center">
                            <span className="bg-black/50 text-white px-4 py-2 rounded-full backdrop-blur-md text-sm">Preview Mode</span>
                        </div>
                    </div>
                ) : (
                    <div className="text-center text-slate-500">
                        <Sparkles className="w-12 h-12 mx-auto mb-4 opacity-20" />
                        <p>Ready to create magic.</p>
                    </div>
                )}

                {/* Download Button Overlay for Images */}
                {generatedImage && (
                    <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                         <a 
                            href={generatedImage} 
                            download={`pixelmagic-${Date.now()}.png`}
                            className="bg-white/10 hover:bg-white/20 backdrop-blur text-white p-2 rounded-lg flex items-center gap-2 border border-white/10"
                        >
                            <Download className="w-5 h-5" />
                         </a>
                    </div>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};