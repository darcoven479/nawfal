import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

export const BackgroundPattern: React.FC = () => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const svg = d3.select(svgRef.current);
    const width = window.innerWidth;
    const height = window.innerHeight;

    svg.attr("width", width).attr("height", height);

    // Create random circles
    const data = d3.range(20).map(() => ({
      x: Math.random() * width,
      y: Math.random() * height,
      r: Math.random() * 50 + 10,
      opacity: Math.random() * 0.1
    }));

    svg.selectAll("circle")
      .data(data)
      .enter()
      .append("circle")
      .attr("cx", d => d.x)
      .attr("cy", d => d.y)
      .attr("r", d => d.r)
      .style("fill", "#6366f1")
      .style("opacity", d => d.opacity)
      .transition()
      .duration(20000)
      .ease(d3.easeLinear)
      .style("opacity", 0.05)
      .attr("cx", d => d.x + (Math.random() - 0.5) * 200)
      .attr("cy", d => d.y + (Math.random() - 0.5) * 200);

    const handleResize = () => {
        svg.attr("width", window.innerWidth).attr("height", window.innerHeight);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        <svg ref={svgRef} className="absolute inset-0 w-full h-full opacity-30" />
    </div>
  );
};
