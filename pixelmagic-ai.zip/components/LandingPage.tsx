import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, Wand2, Scissors, Image as ImageIcon, Zap, FileText, X } from 'lucide-react';
import { UsageStats } from './UsageStats';

interface LandingPageProps {
  onStart: () => void;
}

interface Feature {
  id: string;
  title: string;
  icon: React.ReactNode;
  shortDesc: string;
  fullDesc: string;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onStart }) => {
  const [selectedFeature, setSelectedFeature] = useState<Feature | null>(null);

  const features: Feature[] = [
    {
      id: 'remove-bg',
      title: 'Background Removal',
      icon: <Scissors className="w-6 h-6 text-white" />,
      shortDesc: 'Remove unwanted backgrounds in seconds. Perfect for e-commerce and professional presentations.',
      fullDesc: 'Our intelligent AI separates the foreground subject from the background with pixel-perfect precision. Whether it’s complicated hair details, transparent objects, or busy backgrounds, PixelMagic handles it instantly. This tool is essential for e-commerce product listings, creating professional headshots, or making stickers and marketing materials.'
    },
    {
      id: 'image-edit',
      title: 'AI Image Editing',
      icon: <Wand2 className="w-6 h-6 text-white" />,
      shortDesc: 'Enhance, retouch, or modify images. Adjust lighting, remove blemishes, and refine details.',
      fullDesc: 'Edit your photos using natural language. Simply type what you want to change—"Make it a sunny day", "Add a red hat", or "Remove the person in the background"—and the AI does the rest. It understands context, lighting, and style to ensure your edits look completely natural.'
    },
    {
      id: 'enhance',
      title: 'Quality Enhancement',
      icon: <Zap className="w-6 h-6 text-white" />,
      shortDesc: 'Turn blurry photos into sharp, high-definition images using advanced AI upscaling.',
      fullDesc: 'Revitalize old or low-resolution images. Our upscale technology adds realistic detail, reduces noise, and sharpens edges to convert small, blurry photos into crisp, high-definition masterpieces suitable for large prints or high-quality web displays.'
    },
    {
      id: 'generate',
      title: 'AI-Generated Images',
      icon: <ImageIcon className="w-6 h-6 text-white" />,
      shortDesc: 'Create unique, stunning visuals from text prompts. Art, concepts, and stock photos.',
      fullDesc: 'Turn text into art. Using Gemini Pro visualization capabilities, you can generate anything from photorealistic landscapes to abstract art, 3D renders, and character designs. Perfect for overcoming creative blocks or generating custom assets for your projects.'
    },
    {
      id: 'image-to-prompt',
      title: 'Image to Prompt',
      icon: <FileText className="w-6 h-6 text-white" />,
      shortDesc: 'Convert any image into a detailed text prompt to understand its style and composition.',
      fullDesc: 'Reverse engineer the magic. Upload any image, and our AI will analyze it to generate a detailed text prompt. This description captures the style, lighting, composition, and subject matter, allowing you to recreate similar images or learn how to write better prompts.'
    }
  ];

  return (
    <div className="flex flex-col gap-20 pb-20 relative">
      
      {/* Feature Modal */}
      {selectedFeature && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm" onClick={() => setSelectedFeature(null)}>
          <div className="bg-slate-800 border border-slate-700 rounded-2xl p-8 max-w-lg w-full shadow-2xl relative" onClick={e => e.stopPropagation()}>
            <button 
              onClick={() => setSelectedFeature(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white transition"
            >
              <X className="w-6 h-6" />
            </button>
            <div className="w-14 h-14 bg-indigo-600 rounded-xl flex items-center justify-center mb-6 shadow-lg shadow-indigo-500/20">
              {selectedFeature.icon}
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">{selectedFeature.title}</h3>
            <p className="text-slate-300 leading-relaxed mb-8">
              {selectedFeature.fullDesc}
            </p>
            <button 
              onClick={() => {
                setSelectedFeature(null);
                onStart();
              }}
              className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 rounded-xl transition flex items-center justify-center gap-2"
            >
              Try This Feature <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 px-4 sm:px-6 lg:px-8 overflow-hidden">
        <div className="max-w-7xl mx-auto text-center relative z-10">
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-white mb-6">
            Transform Your Images with <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">AI Magic</span>
          </h1>
          <p className="mt-4 text-xl text-slate-400 max-w-2xl mx-auto mb-10">
            Enhance. Edit. Remove. Create. All in One Place. 
            Experience the power of Gemini 2.5 to effortlessly transform your visuals.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button 
              onClick={onStart}
              className="group bg-indigo-600 hover:bg-indigo-500 text-white text-lg px-8 py-4 rounded-full font-bold transition-all shadow-[0_0_20px_rgba(79,70,229,0.5)] flex items-center gap-2"
            >
              Start Creating Now <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="text-slate-400 hover:text-white font-medium px-6 py-4">
              View Gallery
            </button>
          </div>
        </div>
      </section>

      {/* About Us */}
      <section className="max-w-5xl mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
            <h2 className="text-3xl font-bold text-white">Welcome to PixelMagic</h2>
            <p className="text-lg text-slate-400 leading-relaxed">
                Experience the power of AI to effortlessly transform your images. Whether you’re a designer, 
                marketer, e-commerce seller, or content creator, our platform provides the tools to make 
                your visuals stand out.
            </p>
            <div className="grid grid-cols-2 gap-4 pt-4">
                <div className="flex items-center gap-2 text-slate-300">
                    <CheckCircle2 className="w-5 h-5 text-green-400" /> Professional Grade
                </div>
                <div className="flex items-center gap-2 text-slate-300">
                    <CheckCircle2 className="w-5 h-5 text-green-400" /> Instant Results
                </div>
                <div className="flex items-center gap-2 text-slate-300">
                    <CheckCircle2 className="w-5 h-5 text-green-400" /> Secure Processing
                </div>
                <div className="flex items-center gap-2 text-slate-300">
                    <CheckCircle2 className="w-5 h-5 text-green-400" /> Creative Freedom
                </div>
            </div>
        </div>
        <div className="relative">
            <UsageStats />
            <div className="absolute -z-10 -top-10 -right-10 w-64 h-64 bg-purple-600/20 rounded-full blur-3xl"></div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-white mb-4">Our Services</h2>
            <p className="text-slate-400">Click on any feature to learn more.</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
            {features.map((feature) => (
              <div 
                key={feature.id}
                onClick={() => setSelectedFeature(feature)}
                className="bg-slate-800/50 backdrop-blur border border-slate-700 p-6 rounded-2xl hover:border-indigo-500 transition duration-300 group cursor-pointer hover:bg-slate-800"
              >
                  <div className="w-12 h-12 bg-slate-700 rounded-lg flex items-center justify-center mb-4 group-hover:bg-indigo-600 transition shadow-inner">
                      {feature.icon}
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
                  <p className="text-slate-400 text-sm line-clamp-3">{feature.shortDesc}</p>
              </div>
            ))}
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="bg-slate-800/30 py-16">
          <div className="max-w-7xl mx-auto px-4">
              <h2 className="text-3xl font-bold text-white mb-12 text-center">Why Choose Us</h2>
              <div className="grid md:grid-cols-4 gap-8 text-center">
                  <div>
                      <h4 className="text-indigo-400 font-bold text-lg mb-2">Fast & Efficient</h4>
                      <p className="text-slate-400">Get results in seconds with optimized Gemini Flash models.</p>
                  </div>
                  <div>
                      <h4 className="text-indigo-400 font-bold text-lg mb-2">User-Friendly</h4>
                      <p className="text-slate-400">No design skills needed. Simple intuitive interface.</p>
                  </div>
                  <div>
                      <h4 className="text-indigo-400 font-bold text-lg mb-2">Affordable</h4>
                      <p className="text-slate-400">Professional quality AI tools available to everyone.</p>
                  </div>
                  <div>
                      <h4 className="text-indigo-400 font-bold text-lg mb-2">Versatile</h4>
                      <p className="text-slate-400">Ideal for social media, marketing, and creative projects.</p>
                  </div>
              </div>
          </div>
      </section>

      {/* Call to Action */}
      <section className="max-w-4xl mx-auto px-4 text-center">
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-3xl p-12 shadow-2xl">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Start Transforming Your Images Today!</h2>
            <p className="text-indigo-100 mb-8 max-w-xl mx-auto">
                See how AI can revolutionize the way you create and edit visuals.
            </p>
            <button 
                onClick={onStart}
                className="bg-white text-indigo-600 px-8 py-4 rounded-full font-bold hover:bg-indigo-50 transition shadow-lg"
            >
                Launch Editor
            </button>
        </div>
      </section>
    </div>
  );
};
