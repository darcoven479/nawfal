import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { LandingPage } from './components/LandingPage';
import { AppWorkspace } from './components/AppWorkspace';
import { AppView } from './types';
import { BackgroundPattern } from './components/BackgroundPattern';

export default function App() {
  const [currentView, setCurrentView] = useState<AppView>(AppView.LANDING);

  return (
    <>
      <BackgroundPattern />
      <Layout 
        currentView={currentView} 
        onNavigate={setCurrentView}
      >
        {currentView === AppView.LANDING ? (
          <LandingPage onStart={() => setCurrentView(AppView.APP)} />
        ) : (
          <AppWorkspace />
        )}
      </Layout>
    </>
  );
}
